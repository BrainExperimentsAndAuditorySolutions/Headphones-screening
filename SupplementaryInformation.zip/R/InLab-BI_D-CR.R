# Clear the plots
dev.off()
# First clear the workspace data:
rm(list = ls())
# Clear the console:
cat("\014")


# Load the data
RT <- read.csv("..\\RawData\\InLabControl.csv")
RT$CRf<-factor(RT$CR, levels = c(0, 1))
library(caret)
'%ni%' <- Negate('%in%')  # define 'not in' func
options(scipen=999)  # prevents printing scientific notations.
# Down Sample
set.seed(100)
down_RT <- RT # prevent downsampling, because of low sample size; =downSample(x = RT[, colnames(RT) %ni% "BI_Df"],y = RT$BI_Df)
colnames(down_RT)[colnames(down_RT)=="Class"] <- "CRf"
table(down_RT$CRf)
CRf <- down_RT$CRf
table(CRf)

BI_Df <- factor(down_RT$BI_D, levels = c(0, 1))

y_pred <- BI_Df
y_act <- CRf

# Accuracy:
mean(y_pred == y_act)  
# Confusion Matrix
caret::confusionMatrix(y_pred, y_act, positive="1", mode="everything")
# Receiver Operating Characteristics (ROC) curve
InformationValue::plotROC(RT$CR, RT$BI_D)
InformationValue::AUROC(RT$CR, RT$BI_D)
# Concordance and Discordance
InformationValue::Concordance(RT$CR, RT$BI_D)
# Gini Coefficient is an indicator of how well the model outperforms random predictions. 
# Closer to 1 means great model. Closer to zero means close to random prediction.
# It can be computed from the area under the ROC curve using the following formula:
# Gini Coefficient = (2 * AUROC) - 1
Gini <- 2*InformationValue::AUROC(RT$CR, RT$BI_D) - 1
Gini


#install.packages("irr")
library(irr)
kappa2(cbind(y_act,y_pred))

#install.packages("fmsb")
library(fmsb)
Kappa.test(y_act,y_pred)
