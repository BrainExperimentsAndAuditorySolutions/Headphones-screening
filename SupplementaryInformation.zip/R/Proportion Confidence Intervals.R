# Clear the plots
dev.off()
# First clear the workspace data:
rm(list = ls())
# Clear the console:
cat("\014")

#install.packages("prevalence")
library(prevalence)

#BATCH1-TurkChooseFreely#####################################################################
# Inferred surround proportion
propCI(x = 	259	, n = 	1369	, method="exact")	
# Prevalences
propCI(x = 	1369	, n = 	1656	, method="exact")	# Passed initial disqualification
propCI(x = 	544	, n = 	1656	, method="exact")	# BI_D dichotic predictions
propCI(x = 	569	, n = 	1656	, method="exact")	# BI_A dichotic predictions
propCI(x = 	604	, n = 	1656	, method="exact")	# SI_A dichotic predictions
propCI(x = 	803	, n = 	1656	, method="exact")	# SI_D dichotic predictions
  # Disqualifications per criterion
propCI(x = 	2	, n = 	287	, method="exact")	
propCI(x = 	102	, n = 	287	, method="exact")	
propCI(x = 	95	, n = 	287	, method="exact")	
propCI(x = 	158	, n = 	287	, method="exact")	
  # Proportions of SI vs BI errors
propCI(x = 	1302	, n = 	1656	, method="exact")	
propCI(x = 	354	, n = 	1656	, method="exact")	
propCI(x = 	1526	, n = 	1656	, method="exact")	
propCI(x = 	130	, n = 	1656	, method="exact")	
propCI(x = 	1163	, n = 	1656	, method="exact")	
propCI(x = 	493	, n = 	1656	, method="exact")	
propCI(x = 	1153	, n = 	1656	, method="exact")	
propCI(x = 	503	, n = 	1656	, method="exact")	
   # BI_A matchid BI_D in relation to the whole sample size
propCI(x = 	1112	, n = 	1656	, method="exact")	
  # Dichotic results predicted by the BI method (BI_A matching BI_D, both predicting dichotic result)
propCI(x = 	428	, n = 	1656	, method="exact")	
  # Non-Dichotic results predicted by the BI method (BI_A matching BI_D, both predicting dichotic result)
propCI(x = 	684	, n = 	1656	, method="exact")	

#BATCH2-TurkMustWear#####################################################
#All data
propCI(x = 	35	, n = 	519	, method="exact")	# SI_D (WearHp) declared wearing headphones proportion
#Data that passed initial disqualification
propCI(x = 	451	, n = 	519	, method="exact")	# Passed initial disqualification
propCI(x = 	309	, n = 	519	, method="exact")	# BI_D dichotic predictions
propCI(x = 	307	, n = 	519	, method="exact")	# BI_A dichotic predictions
propCI(x = 	284	, n = 	519	, method="exact")	# SI_A dichotic predictions
propCI(x = 	434	, n = 	519	, method="exact")	# SI_D dichotic predictions
  # Disqualifications per criterion
propCI(x = 	0	, n = 	68	, method="exact")	
propCI(x = 	25	, n = 	68	, method="exact")	
propCI(x = 	23	, n = 	68	, method="exact")	
propCI(x = 	37	, n = 	68	, method="exact")	
  # Proportion of records predicted as "not wearing headphones" by the Static Interference Method
propCI(x = 	192	, n = 	519	, method="exact")	
  # Proportions of SI vs BI errors
propCI(x = 	367	, n =  519	, method="exact")	
propCI(x = 	152	, n = 	 519	, method="exact")	
propCI(x = 	455	, n =  519	, method="exact")	
propCI(x = 	64	, n = 	 519	, method="exact")	
propCI(x = 	248	, n =  519	, method="exact")	
propCI(x = 	271	, n = 	 519	, method="exact")	
propCI(x = 	247	, n =  519	, method="exact")	
propCI(x = 	272	, n = 	 519	, method="exact")	
  # BI_A matchid BI_D in relation to the whole sample size
propCI(x = 	351	, n = 	519	, method="exact")	
  # Dichotic results predicted by the BI method (BI_A matching BI_D, both predicting dichotic result)
propCI(x = 	258	, n = 	519	, method="exact")	
  # Non-Dichotic results predicted by the BI method (BI_A matching BI_D, both predicting dichotic result)
propCI(x = 	93	, n = 	519	, method="exact")	


#InLab-False Positives for SI#####################################################
propCI(x = 	1	, n = 	18	, method="exact")	# from the sample size
propCI(x = 	1	, n = 	4	, method="exact")	 # from the declared dichotic results

# BATCH 1: SI vs BI confusion matrix
propCI(x = 61	, n = 	1656	, method="exact")	
propCI(x = 147	, n = 	1656	, method="exact")	
propCI(x = 263	, n = 	1656	, method="exact")	
propCI(x = 691	, n = 	1656	, method="exact")	
propCI(x = 202	, n = 	1656	, method="exact")	



