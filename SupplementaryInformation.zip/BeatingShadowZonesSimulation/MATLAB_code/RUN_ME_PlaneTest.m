%Action='Show wave';
Action='Show Beating Intensity';


close;
 
for df=50 % diference of the two sources' frequencies
    
    squareSideLength=3; % in meters
    squareSidePixels=300; % resolution - how many pixels per side-length

    p=SquarePlane(squareSideLength,squareSidePixels);
    speed=340; % meters in second
    
    f1=500; waveLength1=speed/f1; % Hz
    f2=f1+df; waveLength2=speed/f2; % Hz
    
    source1Pos=[squareSideLength*0.45 ... % in meters: X coordinate of source position
                squareSideLength*0.8];  % in meters: Y coordinate of source position
    source2Pos=[squareSideLength*0.55 ... % in meters: X coordinate of source position
                squareSideLength*0.8];  % in meters: Y coordinate of source position

%     f3=f1-100; waveLength3=speed/f3;
%     f4=f3+df; waveLength4=speed/f4;
%     source3Pos=source1Pos;
%     source4Pos=source2Pos; 

    sourceAmplitude=1; % arbitrary units
    maxPossibleAmplitude = sourceAmplitude*4; % this is used as an initial value to find the min elongations (if one is found lower than this, it will replace this maxPossible value)
    p.MaxElongations = 0*p.Elongations;
    p.MinElongations = maxPossibleAmplitude;
    reflected=1; nonReflected=0; % this is the value of the parameter that tell s the MixWave method if the wave is reflected or not; see how is used in the MixWave method.
    reflectionAmplification=1; % atenuation factor of the reflection; a value of 1 means that there is no atenuation, nor amplification

    wallY=0;    % This is the Y coordinate of wall;
                % The wall is parallel to the X axis - see lab journal page 233(*)
                % ##### IMPORTANT: use wallY<0 for the wall to be outside of the plane!

    trackingDuration=4/abs(f1-f2); % how long in time axis to track the amplitudes; must cover one full beating period, to be sure we camptured all possible values.

    timeIndex=1; % snapshot index (order number)
 
    % preparation for animation or drawint - START
    figure1=  figure('Color',[1 1 1]);
    set(figure1, 'Position', get(0, 'Screensize'));
    colormap(copper);
    axes1 = axes('Parent',figure1);
    % preparation for animation or drawint - END
    
    for time=0:0.0001:trackingDuration
        p.Elongations=0*p.Elongations;
        
        MixWave(p,source1Pos,sourceAmplitude,f1,340,time,nonReflected);
        MixWave(p,source2Pos,sourceAmplitude,f2,340,time,nonReflected);

        MixWave(p,source1Pos,sourceAmplitude*reflectionAmplification,f1,340,time,reflected,wallY);   
        MixWave(p,source2Pos,sourceAmplitude*reflectionAmplification,f2,340,time,reflected,wallY);   
        
%         MixWave(p,source3Pos,sourceAmplitude,f3,340,time,nonReflected);
%         MixWave(p,source4Pos,sourceAmplitude,f4,340,time,nonReflected);
% 
%         MixWave(p,source3Pos,sourceAmplitude*reflectionAmplification,f3,340,time,reflected,wallY);   
%         MixWave(p,source4Pos,sourceAmplitude*reflectionAmplification,f4,340,time,reflected,wallY);   
       

        p.ElongationTimeStamps(:,:,timeIndex)=p.Elongations;

        p.Extremes =    ( (abs(p.Elongations)<abs(p.PreviousElongations)) ...
                            & ...
                          (abs(p.PreviousElongations)>abs(p.BeforePreviousElongations)) ...
                        ) ...
                        .* (p.PreviousElongations>0)...
                        .* p.PreviousElongations;    


        p.MaxElongations=max(p.MaxElongations,p.Extremes);
        p.MinElongations=min(p.MinElongations,maxPossibleAmplitude*(p.Extremes==0)+p.Extremes);

        p.BeforePreviousElongations = p.PreviousElongations;
        p.PreviousElongations = p.Elongations;

        % The following 6 lines plots the real-time movement of the wave
         figure(figure1);
          surf((p.Elongations)','Parent',axes1,'LineStyle','none');              
          zlim([-5 25]);
          xlim([0 squareSidePixels]);
          ylim([0 squareSidePixels]);
          view(axes1,[timeIndex 30]);
        % The upper 6 lines plots the real-time movement of the wave          
              
        pause(1/100000);  
        timeIndex=timeIndex+1;
    end

    % the following code plots the "intensity" of the beats
    figure(figure1);             
    surf((p.MaxElongations-p.MinElongations)','Parent',axes1,'LineStyle','none');
    zlim([-5 25]);
    xlim([0 squareSidePixels]);
    ylim([0 squareSidePixels]);
    view(axes1,[45 30]);
    set(figure1, 'Position', get(0, 'Screensize'));

end   
