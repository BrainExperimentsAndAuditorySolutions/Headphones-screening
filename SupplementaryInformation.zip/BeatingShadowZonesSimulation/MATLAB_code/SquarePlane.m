classdef SquarePlane < handle   
    properties
        Elongations
        SideLength
        SidePixels
        Resolution
        % time stamps
        ElongationTimeStamps
        % misc
        PreviousElongations
        BeforePreviousElongations
        MaxElongations
        MinElongations
        Extremes
        Positives
    end
    
    methods
        function obj = SquarePlane(sideLength,sidePixels)
            obj.SidePixels = sidePixels;
            obj.SideLength = sideLength;
            obj.Resolution = sideLength/sidePixels;
            obj.Elongations = zeros(sidePixels,sidePixels);
            obj.PreviousElongations = obj.Elongations;
            obj.BeforePreviousElongations = obj.Elongations;
            obj.Extremes = obj.Elongations;
            obj.Positives = obj.Elongations;
            obj.MaxElongations = obj.Elongations-Inf;
            obj.MinElongations = obj.Elongations+Inf;
            obj.ElongationTimeStamps(:,:,1)=obj.Elongations;
        end
    end
end

