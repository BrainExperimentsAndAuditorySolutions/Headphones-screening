function MixWave(Plane,SourcePosition,Amplitude,Frequency,WaveSpeed,time,reflected, wallY)
%MIXWAVE Summary of this function goes here
%   Detailed explanation goes here
% - Plane is the NxN vector-plane of spatial displacement values caused by
%   the wave
% - SourcePosition is the 1x2 vector of the sound source position on the
%   Plane
% - Amplitude is the amplitude of the wave in meter
% - Frequency is the wave frequency in Hertz
% - WaveSpeed is the wave speed in meter/second
% - reflected = 1:is a reflected wave, 0:is not a reflected wave
% - wallY - the wall is parallel to the X axis

angularFrequency = 2*3.1415926*Frequency;
waveNumber = angularFrequency/WaveSpeed;
sourcePixel = round(SourcePosition/Plane.Resolution);
phase=0;

%     if( (SourcePosition(1)<0) ...
%         || ...
%         (SourcePosition(2)<0) ...
%         || ...
%         (SourcePosition(1)>Plane.SideLength) ...
%         || ...
%         (SourcePosition(2)>Plane.SideLength)...
%        )
%             error('The source must be inside the Plane.');
%
%     end
if(reflected==0)
    possibleRadiusPixels = 0:ceil(sqrt(2)*Plane.SidePixels);
else % see lab journal page 233/(*)
    wallYpixels =  round(wallY/Plane.Resolution);
    possibleRadiusPixels = 0:ceil(sqrt(Plane.SidePixels*Plane.SidePixels...
        +4*(sourcePixel(2) - wallYpixels)^2))*2;
    % phase=pi; https://en.wikipedia.org/wiki/Reflection_phase_change 
end

possibleRadiusLengths = Plane.Resolution*possibleRadiusPixels;

%possibleRadiusLengths
%angularFrequency*time-waveNumber*possibleRadiusLengths
%     angularFrequency*time
%     waveNumber*possibleRadiusLengths

possibleWaveElongations = Amplitude * ...
    cos(angularFrequency*time-waveNumber*possibleRadiusLengths+phase);
%possibleWaveElongations

%     clf;
%     plot(possibleWaveElongations);

radiusPixels=zeros(Plane.SidePixels,Plane.SidePixels);
if(reflected==0)
    for x=0:Plane.SidePixels-1
        for y=0:Plane.SidePixels-1
            deltaX=x-sourcePixel(1);
            deltaY=y-sourcePixel(2);
            radiusPixels(x+1,y+1)=round(sqrt(deltaX*deltaX+deltaY*deltaY));
        end
    end
else
    for x=0:Plane.SidePixels-1
        for y=0:Plane.SidePixels-1
            mappedX=x;
            mappedY=2*wallYpixels-y;
            deltaX=mappedX-sourcePixel(1);
            deltaY=mappedY-sourcePixel(2);
            % According to lab journal page 228(**):
            radiusPixels(x+1,y+1)=round(sqrt(deltaX*deltaX+deltaY*deltaY));
        end
    end
end

%surf(radiusPixels)
%save;

Plane.Elongations = Plane.Elongations + possibleWaveElongations(radiusPixels+1);

end

